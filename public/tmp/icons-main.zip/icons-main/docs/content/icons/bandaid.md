---
title: Bandaid
categories:
  - Real world
tags:
  - bandage
  - health
---
