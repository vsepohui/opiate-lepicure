---
title: Beaker
categories:
  - Real world
tags:
  - beaker
  - science
  - measure
  - experiment
---
