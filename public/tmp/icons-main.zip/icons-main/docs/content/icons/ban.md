---
title: Ban
categories:
  - Real world
tags:
  - no
  - "not allowed"
  - block
added: 1.11.0
---
