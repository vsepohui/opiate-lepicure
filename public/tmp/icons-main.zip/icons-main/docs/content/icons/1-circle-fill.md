---
title: 1 circle fill
categories:
  - Shapes
tags:
  - number
  - numeral
---
