---
title: Arrow left square fill
categories:
  - Shape arrows
tags:
  - arrow
  - square
---
